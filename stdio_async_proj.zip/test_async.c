#include <stdlib.h>
#include <stdio.h> /* system for printf */
#include <string.h>
/* Include our custom header AFTER to override async APIs and pick decls.
   We'll place it with -I path so "stdio.h" resolves to our custom one first. */
#include "stdio.h"

static void on_ok(void *val, void *ctx){
    const char *tag = (const char*)ctx;
    printf("[OK] %s\n", tag);
    (void)val;
}

static void on_err(void *err, void *ctx){
    const char *tag = (const char*)ctx;
    int e = err ? *(int*)err : -1;
    printf("[ERR] %s errno=%d\n", tag, e);
}

int main(void){
    printf("START\n"); fflush(stdout);
    const char *path = "/tmp/testfile_async.txt";
    const char *msg  = "hello async world\n";

    promise_t *popen = fopen_async(path, "wb+");
    promise_then(popen, on_ok, on_err, (void*)"fopen_async");

    void *res=NULL;
    if(promise_await(popen, &res)!=PROMISE_RESOLVED){
        printf("fopen_async failed\n");
        return 1;
    }
    FILE *fp = (FILE*)res;

    promise_t *pwrite = fwrite_async(fp, msg, 1, strlen(msg));
    promise_then(pwrite, on_ok, on_err, (void*)"fwrite_async");
    promise_await(pwrite, NULL);

    /* rewind synchronously to test fread */
    rewind(fp);

    char buf[128]={0};
    promise_t *pread = fread_async(fp, buf, 1, sizeof(buf)-1);
    promise_then(pread, on_ok, on_err, (void*)"fread_async");
    void *rbytes=NULL;
    promise_await(pread, &rbytes);
    size_t n = rbytes ? *(size_t*)rbytes : 0;
    if(rbytes) free(rbytes);
    buf[n] = '\0';
    printf("Read(%zu): %s", n, buf);

    promise_t *pflush = fflush_async(fp);
    promise_then(pflush, on_ok, on_err, (void*)"fflush_async");
    promise_await(pflush, NULL);

    promise_t *pclose = fclose_async(fp);
    promise_then(pclose, on_ok, on_err, (void*)"fclose_async");
    promise_await(pclose, NULL);

    printf("END\n"); fflush(stdout);
    return 0;
}