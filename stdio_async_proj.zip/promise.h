// promise.h
#ifndef PROMISE_H
#define PROMISE_H

typedef enum {
    PROMISE_PENDING,
    PROMISE_RESOLVED,
    PROMISE_REJECTED
} promise_state_t;

typedef struct promise_t promise_t;
typedef void (*promise_callback_t)(void *value, void *context);

struct promise_t {
    promise_state_t state;
    void *value;
    void *error;
    promise_callback_t on_fulfilled;
    promise_callback_t on_rejected;
    void *context;
    /* internal synchronization */
    void *mutex; /* mtx_t* stored opaquely to avoid including threads.h in header */
    void *cond;  /* cnd_t* */
};

promise_t *promise_create(void);
void promise_destroy(promise_t *p);
void promise_resolve(promise_t *p, void *value);
void promise_reject(promise_t *p, void *error);
void promise_then(promise_t *p, promise_callback_t on_fulfilled, promise_callback_t on_rejected, void *context);

/* Optional: blocking wait returning state; sets *out to value or error */
promise_state_t promise_await(promise_t *p, void **out);

#endif