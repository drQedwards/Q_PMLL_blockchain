/* stdio_async.c — thread fallback backend */
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <string.h>
#include <threads.h>
#include <stdint.h>
#include <stdio.h>
#include <unistd.h>
#define DEBUG_ASYNC 1

/* Include the custom header name to avoid clashing with system stdio.h. */
#include "stdio.h"

#if STDIO_ENABLE_ASYNC && STDIO_ASYNC_BACKEND==0 && defined(STDIO_ASYNC_USE_THREADS)


static char *xstrdup(const char *s){
    if(!s) return NULL;
    size_t n = strlen(s)+1;
    char *p = (char*)malloc(n);
    if(p) memcpy(p, s, n);
    return p;
}
static stdio_event_callback_t g_cb = NULL;
static void *g_cb_ud = NULL;

void set_stdio_event_hook(stdio_event_callback_t cb, void *ud){
    g_cb = cb; g_cb_ud = ud;
}

static void settle_ok_ptr(promise_t *p, void *ptr, FILE *fp_maybe){
    promise_resolve(p, ptr);
    if(g_cb && fp_maybe) g_cb(fp_maybe, g_cb_ud);
}

static void settle_ok_size(promise_t *p, size_t n, FILE *fp){
    size_t *ret = (size_t*)malloc(sizeof(size_t));
    if(!ret){ int *pe = (int*)malloc(sizeof(int)); if(pe){*pe=ENOMEM;} promise_reject(p, pe); return; }
    *ret = n;
    promise_resolve(p, ret);
    if(g_cb) g_cb(fp, g_cb_ud);
}

static void settle_ok_int(promise_t *p, int v, FILE *fp){
    int *ret = (int*)malloc(sizeof(int));
    if(!ret){ int *pe = (int*)malloc(sizeof(int)); if(pe){*pe=ENOMEM;} promise_reject(p, pe); return; }
    *ret = v;
    promise_resolve(p, ret);
    if(g_cb) g_cb(fp, g_cb_ud);
}

static void settle_err_errno(promise_t *p){
    int *pe = (int*)malloc(sizeof(int));
    if(pe) *pe = errno; 
    promise_reject(p, pe);
}

/* Generic thread runner wrapper */
typedef int (*work_fn_t)(void *);

struct job {
    work_fn_t fn;
    void *arg;
    promise_t *p;
    FILE *fp_for_cb;
    enum {RET_PTR, RET_SIZE, RET_INT} rettype;
};

static int thread_entry(void *v){
#if DEBUG_ASYNC
fprintf(stderr,"[async] thread_entry start\n");
#endif
    struct job *j = (struct job*)v;
    errno = 0;
    int rv = j->fn(j->arg);
    if(errno){
        settle_err_errno(j->p);
    }else{
        if(j->rettype==RET_PTR)   settle_ok_ptr(j->p, (void*)(intptr_t)rv, j->fp_for_cb);
        else if(j->rettype==RET_SIZE) settle_ok_size(j->p, (size_t)rv, j->fp_for_cb);
        else settle_ok_int(j->p, rv, j->fp_for_cb);
    }
    free(j->arg);
    free(j);
    return 0;
}

static int spawn_job(struct job *j){
    thrd_t t;
    if(thrd_create(&t, thread_entry, j)!=thrd_success) return -1;
    thrd_detach(t);
    return 0;
}

/* --- fopen_async --- */
struct args_open { char *path; char *mode; };
static int work_fopen(void *a_){
    struct args_open *a = (struct args_open*)a_;
    fprintf(stderr,"[async] work_fopen running\n");
    FILE *fp = fopen(a->path, a->mode);
    fprintf(stderr,"[async] work_fopen done fp=%p\n", (void*)fp);
    return (int)(intptr_t)fp;
}
promise_t *fopen_async(const char *path, const char *mode){
    promise_t *p = promise_create(); if(!p) return NULL;
    struct args_open *a = malloc(sizeof *a);
    if(!a){ promise_reject(p, NULL); return p; }
    a->path = xstrdup(path);
    a->mode = xstrdup(mode);
    if(!a->path || !a->mode){ free(a->path); free(a->mode); free(a); settle_err_errno(p); return p; }
    struct job *j = calloc(1,sizeof *j);
    if(!j){ free(a->path); free(a->mode); free(a); promise_reject(p,NULL); return p; }
    j->fn = work_fopen; j->arg = a; j->p = p; j->rettype=RET_PTR; j->fp_for_cb=NULL;
    #if DEBUG_ASYNC
fprintf(stderr,"[async] spawn fopen job\n");
#endif
    if(spawn_job(j)<0){ free(a->path); free(a->mode); free(a); free(j); settle_err_errno(p); }
    return p;
}

/* --- fclose_async --- */
struct args_fclose { FILE *fp; };
static int work_fclose(void *a_){
    struct args_fclose *a = (struct args_fclose*)a_;
    fprintf(stderr,"[async] work_fclose running\n");
    int r = fclose(a->fp);
    fprintf(stderr,"[async] work_fclose done r=%d\n", r);
    return r;
}
promise_t *fclose_async(FILE *fp){
    promise_t *p = promise_create(); if(!p) return NULL;
    struct args_fclose *a = malloc(sizeof *a); if(!a){ promise_reject(p,NULL); return p; }
    a->fp = fp;
    struct job *j = calloc(1,sizeof *j); if(!j){ free(a); promise_reject(p,NULL); return p; }
    j->fn = work_fclose; j->arg = a; j->p = p; j->rettype=RET_INT; j->fp_for_cb=fp;
    #if DEBUG_ASYNC
fprintf(stderr,"[async] spawn fopen job\n");
#endif
    if(spawn_job(j)<0){ free(a); free(j); settle_err_errno(p); }
    return p;
}

/* --- fread_async --- */
struct args_fread { void *ptr; size_t size, nmemb; FILE *fp; };
static int work_fread(void *a_){
    struct args_fread *a = (struct args_fread*)a_;
    fprintf(stderr,"[async] work_fread running\n");
    int fd = fileno(a->fp);
    size_t want = a->size * a->nmemb;
    size_t total = 0;
    unsigned char *p = (unsigned char*)a->ptr;
    while(total < want){
        ssize_t r = read(fd, p+total, want-total);
        if(r < 0){ perror("read"); break; }
        if(r == 0) break;
        total += (size_t)r;
    }
    fprintf(stderr,"[async] work_fread done bytes=%zu\n", total);
    return (int)(total / a->size);
}
promise_t *fread_async(FILE *fp, void *ptr, size_t size, size_t nmemb){
    promise_t *p = promise_create(); if(!p) return NULL;
    struct args_fread *a = malloc(sizeof *a); if(!a){ promise_reject(p,NULL); return p; }
    a->ptr=ptr; a->size=size; a->nmemb=nmemb; a->fp=fp;
    struct job *j = calloc(1,sizeof *j); if(!j){ free(a); promise_reject(p,NULL); return p; }
    j->fn = work_fread; j->arg=a; j->p=p; j->rettype=RET_SIZE; j->fp_for_cb=fp;
    #if DEBUG_ASYNC
fprintf(stderr,"[async] spawn fopen job\n");
#endif
    if(spawn_job(j)<0){ free(a); free(j); settle_err_errno(p); }
    return p;
}

/* --- fwrite_async --- */
struct args_fwrite { const void *ptr; size_t size, nmemb; FILE *fp; };
static int work_fwrite(void *a_){
    struct args_fwrite *a = (struct args_fwrite*)a_;
    fprintf(stderr,"[async] work_fwrite running\n");
    fflush(a->fp);
    int fd = fileno(a->fp);
    size_t want = a->size * a->nmemb;
    size_t total = 0;
    const unsigned char *p = (const unsigned char*)a->ptr;
    while(total < want){
        ssize_t r = write(fd, p+total, want-total);
        if(r < 0){ perror("write"); break; }
        if(r == 0) break;
        total += (size_t)r;
    }
    fprintf(stderr,"[async] work_fwrite done bytes=%zu\n", total);
    return (int)(total / a->size);
}
promise_t *fwrite_async(FILE *fp, const void *ptr, size_t size, size_t nmemb){
    promise_t *p = promise_create(); if(!p) return NULL;
    struct args_fwrite *a = malloc(sizeof *a); if(!a){ promise_reject(p,NULL); return p; }
    a->ptr=ptr; a->size=size; a->nmemb=nmemb; a->fp=fp;
    struct job *j = calloc(1,sizeof *j); if(!j){ free(a); promise_reject(p,NULL); return p; }
    j->fn = work_fwrite; j->arg=a; j->p=p; j->rettype=RET_SIZE; j->fp_for_cb=fp;
    #if DEBUG_ASYNC
fprintf(stderr,"[async] spawn fopen job\n");
#endif
    if(spawn_job(j)<0){ free(a); free(j); settle_err_errno(p); }
    return p;
}

/* --- fflush_async --- */
struct args_fflush { FILE *fp; };
static int work_fflush(void *a_){
    struct args_fflush *a = (struct args_fflush*)a_;
    fprintf(stderr,"[async] work_fflush running\n");
    int r = fflush(a->fp);
    fprintf(stderr,"[async] work_fflush done r=%d\n", r);
    return r;
}
promise_t *fflush_async(FILE *fp){
    promise_t *p = promise_create(); if(!p) return NULL;
    struct args_fflush *a = malloc(sizeof *a); if(!a){ promise_reject(p,NULL); return p; }
    a->fp=fp;
    struct job *j = calloc(1,sizeof *j); if(!j){ free(a); promise_reject(p,NULL); return p; }
    j->fn = work_fflush; j->arg=a; j->p=p; j->rettype=RET_INT; j->fp_for_cb=fp;
    #if DEBUG_ASYNC
fprintf(stderr,"[async] spawn fopen job\n");
#endif
    if(spawn_job(j)<0){ free(a); free(j); settle_err_errno(p); }
    return p;
}

#endif /* thread backend */