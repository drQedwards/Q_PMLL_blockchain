
/* stdiox.h — async-extended stdio, layered on top of system <stdio.h> */
#ifndef _STDIOX_H
#define _STDIOX_H 1

#include <stdio.h>   /* brings FILE, standard functions, macros */
#include <stddef.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdbool.h>

#include "promise.h"

#ifndef STDIO_ENABLE_ASYNC
#define STDIO_ENABLE_ASYNC 1
#endif

#ifndef STDIO_ASYNC_BACKEND
#define STDIO_ASYNC_BACKEND 0 /* threads */
#endif

#ifdef __cplusplus
extern "C" {
#endif

/* Re-declare prototypes exactly as in standard to satisfy some compilers. */
int printf(const char *restrict format, ...);
int fprintf(FILE *restrict stream, const char *restrict format, ...);
int sprintf(char *restrict str, const char *restrict format, ...);
int snprintf(char *restrict str, size_t size, const char *restrict format, ...);
int vprintf(const char *restrict format, va_list ap);
int vfprintf(FILE *restrict stream, const char *restrict format, va_list ap);
int vsprintf(char *restrict str, const char *restrict format, va_list ap);
int vsnprintf(char *restrict str, size_t size, const char *restrict format, va_list ap);

int scanf(const char *restrict format, ...);
int fscanf(FILE *restrict stream, const char *restrict format, ...);
int sscanf(const char *restrict str, const char *restrict format, ...);
int vscanf(const char *restrict format, va_list ap);
int vfscanf(FILE *restrict stream, const char *restrict format, va_list ap);
int vsscanf(const char *restrict str, const char *restrict format, va_list ap);

/* Async API */
#if STDIO_ENABLE_ASYNC
typedef void (*stdio_event_callback_t)(FILE *stream, void *user_data);
void set_stdio_event_hook(stdio_event_callback_t cb, void *user_data);

promise_t *fopen_async(const char *filename, const char *mode);
promise_t *fclose_async(FILE *stream);
promise_t *fread_async(FILE *stream, void *ptr, size_t size, size_t nmemb);
promise_t *fwrite_async(FILE *stream, const void *ptr, size_t size, size_t nmemb);
promise_t *fflush_async(FILE *stream);
#endif

#ifdef __cplusplus
}
#endif
#endif
