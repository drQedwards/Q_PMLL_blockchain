// promise.c - simple C11 threads-based promise
#include <stdlib.h>
#include <string.h>
#include <threads.h>
#include <stddef.h>
#include "promise.h"
#include <stdio.h>
#define DEBUG_PROMISE 1

typedef struct { mtx_t m; cnd_t c; } sync_t;

static sync_t* sync_create(void){
    sync_t *s = (sync_t*)malloc(sizeof(sync_t));
    if(!s) return NULL;
    if(mtx_init(&s->m, mtx_plain)!=thrd_success){ free(s); return NULL; }
    if(cnd_init(&s->c)!=thrd_success){ mtx_destroy(&s->m); free(s); return NULL; }
    return s;
}

static void sync_destroy(sync_t *s){
    if(!s) return;
    cnd_destroy(&s->c);
    mtx_destroy(&s->m);
    free(s);
}

static sync_t* sync_from_mutex(mtx_t *m){
    return (sync_t*)((char*)m - offsetof(sync_t, m));
}

promise_t *promise_create(void){
    promise_t *p = (promise_t*)calloc(1,sizeof(promise_t));
    if(!p) return NULL;
    p->state = PROMISE_PENDING;
    sync_t *s = sync_create();
    if(!s){ free(p); return NULL; }
    p->mutex = &s->m;
    p->cond  = &s->c;
    return p;
}

void promise_destroy(promise_t *p){
    if(!p) return;
    if(p->mutex){
        sync_t *s = sync_from_mutex((mtx_t*)p->mutex);
        sync_destroy(s);
    }
    free(p);
}

static void promise_settle(promise_t *p, promise_state_t st, void *payload, int is_error){
    if(!p) return;
    mtx_t *m = (mtx_t*)p->mutex;
    cnd_t *c = (cnd_t*)p->cond;
    mtx_lock(m);
    if(p->state == PROMISE_PENDING){
#if DEBUG_PROMISE
fprintf(stderr,"[promise] settling state=%d\n", st);
#endif
        p->state = st;
        if(is_error) p->error = payload; else p->value = payload;
        promise_callback_t ok = p->on_fulfilled;
        promise_callback_t err = p->on_rejected;
        void *ctx = p->context;
        if(st==PROMISE_RESOLVED && ok) ok(p->value, ctx);
        else if(st==PROMISE_REJECTED && err) err(p->error, ctx);
        cnd_broadcast(c);
    }
    mtx_unlock(m);
}

void promise_resolve(promise_t *p, void *value){ promise_settle(p, PROMISE_RESOLVED, value, 0); }
void promise_reject (promise_t *p, void *error){ promise_settle(p, PROMISE_REJECTED , error, 1); }

void promise_then(promise_t *p, promise_callback_t on_fulfilled, promise_callback_t on_rejected, void *context){
    if(!p) return;
    mtx_t *m = (mtx_t*)p->mutex;
    mtx_lock(m);
    p->on_fulfilled = on_fulfilled;
    p->on_rejected  = on_rejected;
    p->context      = context;
    if(p->state == PROMISE_RESOLVED && on_fulfilled) on_fulfilled(p->value, context);
    else if(p->state == PROMISE_REJECTED && on_rejected) on_rejected(p->error, context);
    mtx_unlock(m);
}

promise_state_t promise_await(promise_t *p, void **out){
    if(!p) return PROMISE_REJECTED;
    mtx_t *m = (mtx_t*)p->mutex;
    cnd_t *c = (cnd_t*)p->cond;
    mtx_lock(m);
    while(p->state == PROMISE_PENDING){
        cnd_wait(c, m);
    }
    if(out){
        *out = (p->state==PROMISE_RESOLVED)? p->value : p->error;
    }
    mtx_unlock(m);
    return p->state;
}