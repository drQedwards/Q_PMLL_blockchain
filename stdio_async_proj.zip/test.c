
#include "stdiox.h"
#include "promise.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void on_ok(void *val, void *ctx){
    const char *tag = (const char*)ctx;
    fprintf(stdout, "[%s] resolved: %p\n", tag, val);
}

static void on_bytes(void *val, void *ctx){
    size_t n = val ? *(size_t*)val : 0;
    const char *tag = (const char*)ctx;
    fprintf(stdout, "[%s] bytes=%zu\n", tag, n);
}

static void on_err(void *err, void *ctx){
    const char *tag = (const char*)ctx;
    int code = err ? *(int*)err : -1;
    fprintf(stderr, "[%s] rejected errno=%d\n", tag, code);
}

int main(){
    /* Sync path still works with system libc's stdio functions. */
    FILE *fp = fopen("/mnt/data/stdio_async_proj/hello.txt", "w+");
    if(!fp){ perror("fopen"); return 1; }
    fputs("Hello async stdio!\n", fp);
    fflush(fp);
    fseek(fp, 0, SEEK_SET);

    char buf[256]={0};
    fread(buf,1,255,fp);
    printf("SYNC read: %s", buf);
    fclose(fp);

#if STDIO_ENABLE_ASYNC
    /* Async path */
    promise_t *p1 = fopen_async("/mnt/data/stdio_async_proj/afile.txt", "w+");
    void *val=NULL,*err=NULL;
    promise_state_t st = promise_wait(p1, &val, &err);
    if(st != PROMISE_RESOLVED){ fprintf(stderr, "fopen_async failed\n"); return 1; }
    FILE *afp = (FILE*)val;
    const char *msg = "Async write works.\n";
    promise_t *p2 = fwrite_async(afp, msg, 1, strlen(msg));
    promise_then(p2, on_bytes, on_err, "write");
    promise_wait(p2, &val, &err);

    fseek(afp, 0, SEEK_SET);
    char abuf[128]={0};
    promise_t *p3 = fread_async(afp, abuf, 1, sizeof(abuf)-1);
    promise_wait(p3, &val, &err);
    if(val){ size_t got = *(size_t*)val; printf("ASYNC read got %zu: %s", got, abuf); }
    promise_t *p4 = fclose_async(afp);
    promise_wait(p4, &val, &err);
#endif
    return 0;
}
