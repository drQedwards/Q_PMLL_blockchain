/* stdio.h — compat stdio with promise-based async extensions (custom draft) */
#ifndef _STDIO_H
#define _STDIO_H 1

#include <stddef.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdbool.h>

#define STDIO_ENABLE_ASYNC 1
#define STDIO_ASYNC_BACKEND 0
#define STDIO_ASYNC_USE_THREADS 1

#include "promise.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _FILE FILE;
typedef long fpos_t;

extern FILE *stdin;
extern FILE *stdout;
extern FILE *stderr;

/* Formatted I/O */
int printf(const char *format, ...);
int fprintf(FILE *stream, const char *format, ...);
int sprintf(char *str, const char *format, ...);
int snprintf(char *str, size_t size, const char *format, ...);

int vprintf(const char *format, va_list);
int vfprintf(FILE *stream, const char *format, va_list);
int vsprintf(char *str, const char *format, va_list);
int vsnprintf(char *str, size_t size, const char *format, va_list);

/* Scanning */
int scanf(const char *format, ...);
int fscanf(FILE *stream, const char *format, ...);
int sscanf(const char *str, const char *format, ...);

int vscanf(const char *format, va_list);
int vfscanf(FILE *stream, const char *format, va_list);
int vsscanf(const char *str, const char *format, va_list);

/* Character & string I/O */
int fgetc(FILE *stream);
int getc(FILE *stream);
int getchar(void);

int fputc(int c, FILE *stream);
int putc(int c, FILE *stream);
int putchar(int c);

char *fgets(char *s, int n, FILE *stream);
int fputs(const char *s, FILE *stream);
int puts(const char *s);

int ungetc(int c, FILE *stream);

/* File operations */
FILE *fopen(const char *restrict filename, const char *restrict mode);
FILE *freopen(const char *restrict filename, const char *restrict mode, FILE *restrict stream);
int   fclose(FILE *stream);

/* Buffering */
void setbuf(FILE *restrict stream, char *restrict buf);
int  setvbuf(FILE *restrict stream, char *restrict buf, int mode, size_t size);

/* Read/Write */
size_t fread(void *restrict ptr, size_t size, size_t nmemb, FILE *restrict stream);
size_t fwrite(const void *restrict ptr, size_t size, size_t nmemb, FILE *restrict stream);

/* Positioning */
int   fseek(FILE *stream, long offset, int whence);
long  ftell(FILE *stream);
void  rewind(FILE *stream);
int   fgetpos(FILE *restrict stream, fpos_t *restrict pos);
int   fsetpos(FILE *stream, const fpos_t *pos);

/* Flushing & fd */
int   fflush(FILE *stream);
int   fileno(FILE *stream);

void  clearerr(FILE *stream);
int   feof(FILE *stream);
int   ferror(FILE *stream);
void  perror(const char *s);

/* Temp files */
FILE *tmpfile(void);
char *tmpnam(char *s);

/* Macros */
#ifndef EOF
#define EOF (-1)
#endif
#ifndef SEEK_SET
#define SEEK_SET 0
#define SEEK_CUR 1
#define SEEK_END 2
#endif
#ifndef BUFSIZ
#define BUFSIZ 8192
#endif
#ifndef FOPEN_MAX
#define FOPEN_MAX 8
#endif
#ifndef FILENAME_MAX
#define FILENAME_MAX 4096
#endif
#define _IOFBF 0
#define _IOLBF 1
#define _IONBF 2

/* Async extensions */
#if STDIO_ENABLE_ASYNC
typedef void (*stdio_event_callback_t)(FILE *stream, void *user_data);

promise_t *fopen_async(const char *filename, const char *mode);
promise_t *fclose_async(FILE *stream);
promise_t *fread_async(FILE *stream, void *ptr, size_t size, size_t nmemb);
promise_t *fwrite_async(FILE *stream, const void *ptr, size_t size, size_t nmemb);
promise_t *fflush_async(FILE *stream);
void set_stdio_event_hook(stdio_event_callback_t cb, void *user_data);
#endif

#ifdef __cplusplus
}
#endif
#endif /* _STDIO_H */